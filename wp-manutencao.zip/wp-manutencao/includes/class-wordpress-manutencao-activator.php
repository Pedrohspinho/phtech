<?php
/**
 * Fired during plugin activation
 *
 * @since 	1.0.0
 * @author 	Filipe Seabra <eu@filipecsweb.com.br>
 */
class Wordpress_Manutencao_Activator{
	public static function activate(){

	}
}