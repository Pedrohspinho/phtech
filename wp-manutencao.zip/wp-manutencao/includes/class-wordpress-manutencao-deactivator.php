<?php
/**
 * Fired during plugin deactivation
 *
 * @since 	1.0.0
 * @author 	Filipe Seabra <eu@filipecsweb.com.br>
 */
class Wordpress_Manutencao_Deactivator{
	public static function deactivate(){
		
	}
}