<p>Coloque seu WordPress em manutenção, de forma simples e objetiva. E, ao mesmo tempo, escolha entre várias opções:</p>
<ol>
	<li>Desabilite o modo de manutenção sem precisar desativar o plugin;</li>
	<li>Escolha seu modo de manutenção: você pode usar uma página de manutenção ou escolher uma URL para redirecionamento;</li>
	<li>Construa sua página de manutenção, definindo seu próprio HTML, CSS e JS, ou use o padrão;</li>
	<li>Apenas administradores logados poderão ver o site, MAS é possível incluir vários endereços de IP que também poderão ter acesso normal ao site.</li>
</ol>