<?php cpotheme_block('home_tagline', 'heading tagline primary-color-bg dark', 'container'); ?>
