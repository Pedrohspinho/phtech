<section id="subfooter" class="subfooter">
	<div class="container">
		<?php do_action('cpotheme_subfooter'); ?>
	</div>
</section>